/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_395(unsigned *p)
{
    *p = 3281031768U;
}

unsigned getval_355()
{
    return 3277353368U;
}

unsigned getval_400()
{
    return 3284633920U;
}

unsigned addval_447(unsigned x)
{
    return x + 2445773128U;
}

unsigned addval_389(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_174(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_181(unsigned x)
{
    return x + 3348140120U;
}

unsigned getval_269()
{
    return 2421698425U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_452()
{
    return 3221803417U;
}

void setval_383(unsigned *p)
{
    *p = 3229926027U;
}

void setval_385(unsigned *p)
{
    *p = 3552825001U;
}

unsigned getval_241()
{
    return 3531918985U;
}

unsigned getval_435()
{
    return 3525362313U;
}

void setval_393(unsigned *p)
{
    *p = 3269495112U;
}

unsigned getval_418()
{
    return 3281047977U;
}

void setval_458(unsigned *p)
{
    *p = 3676360393U;
}

void setval_160(unsigned *p)
{
    *p = 3221278345U;
}

unsigned addval_220(unsigned x)
{
    return x + 3229929865U;
}

unsigned getval_347()
{
    return 3223372427U;
}

unsigned getval_351()
{
    return 2430634312U;
}

unsigned getval_358()
{
    return 3223899785U;
}

void setval_115(unsigned *p)
{
    *p = 3286272330U;
}

unsigned getval_242()
{
    return 3531919817U;
}

unsigned getval_195()
{
    return 3286273352U;
}

unsigned addval_191(unsigned x)
{
    return x + 3767093416U;
}

unsigned addval_387(unsigned x)
{
    return x + 3526938249U;
}

unsigned addval_404(unsigned x)
{
    return x + 2425406121U;
}

unsigned getval_209()
{
    return 3523789481U;
}

unsigned getval_325()
{
    return 3380924809U;
}

unsigned getval_224()
{
    return 3281048009U;
}

void setval_428(unsigned *p)
{
    *p = 3286272264U;
}

unsigned addval_103(unsigned x)
{
    return x + 3251538310U;
}

void setval_331(unsigned *p)
{
    *p = 3536113289U;
}

void setval_157(unsigned *p)
{
    *p = 2464188744U;
}

unsigned addval_162(unsigned x)
{
    return x + 3523789449U;
}

void setval_139(unsigned *p)
{
    *p = 3286272344U;
}

void setval_382(unsigned *p)
{
    *p = 3221803393U;
}

unsigned getval_190()
{
    return 3251094153U;
}

void setval_259(unsigned *p)
{
    *p = 3247489673U;
}

unsigned addval_492(unsigned x)
{
    return x + 3675836809U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
